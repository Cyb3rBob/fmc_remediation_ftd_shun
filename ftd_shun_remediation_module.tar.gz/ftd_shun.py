#!/usr/bin/env python
"""
Cisco Firepower Management Center (FMC) Remediation module for Temporary Shun
Author: Vagner Silva
Credits: Chetankumar Phulpagare - fmc-remediation-module-xdr
"""

import os
import sys
import time
import xml.etree.ElementTree as ET
import requests

# Dynamically append local ./lib folder to sys.path for FMC environment
script_dir = os.path.dirname(os.path.abspath(__file__))
lib_dir = os.path.join(script_dir, "lib")
if os.path.exists(lib_dir) and lib_dir not in sys.path:
    sys.path.insert(0, lib_dir)

import paramiko

param_1 = sys.argv[1]
param_2 = sys.argv[2]

# Read Firewall Details from instance.conf
tree = ET.parse("instance.conf")
firewall_ip = tree.find("./config/string[@name='firewall_ip']").text
firewall_username = tree.find("./config/string[@name='firewall_username']").text
firewall_password = tree.find("./config/string[@name='firewall_password']").text
firewall_port = tree.find("./config/string[@name='firewall_port']").text

ftd_device = {
    "host": firewall_ip,       # replace with your FTD IP
    "username": firewall_username,          # replace with your username
    "password": firewall_password,          # replace with your password
    "port": int(firewall_port),             # SSH port integer
    "secret": firewall_password   # if enable mode is needed
}

ssh_client = None
try:
    # Initialize SSH client
    ssh_client = paramiko.SSHClient()
    ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    # Connect to the device
    ssh_client.connect(
        hostname=ftd_device["host"],
        port=ftd_device["port"],
        username=ftd_device["username"],
        password=ftd_device["password"],
        timeout=10
    )

    # Start an interactive shell session
    remote_conn = ssh_client.invoke_shell()

    # Send shun command
    time.sleep(1)  
    remote_conn.send("shun " + param_2 + "\n")
    time.sleep(2)
    output = remote_conn.recv(65535).decode("utf-8")
    print("\nShun output:")
    print(output)

except Exception as e:
    print(f"An error occurred: {e}")
finally:
    if ssh_client is not None:
        ssh_client.close()

